const translations = {
  sq:{eyebrow:"E FRESKËT • E SHIJSHME • HALAL",heroTitle:"Shija që të kthen përsëri.",heroText:"Pica, shawarma dhe të preferuarat e fast food-it — përgatitur me kujdes dhe gati për ty.",viewMenu:"Shiko menunë",madeFresh:"Përgatitur me kujdes",ourMenu:"MENUJA JONË",chooseFavorite:"Zgjidh të preferuarën.",menuSub:"Shiko përbërësit dhe çmimin e çdo produkti.",hungry:"A JE I URITUR?",readyToOrder:"Gati për porosinë tënde?",orderText:"Na kontakto për porosi ose pyetje rreth produkteve.",callUs:"Na telefono",footerText:"Shije e mirë. Përgatitur me kujdes.",ingredients:"PËRBËRËSIT",all:"Të gjitha",loading:"Po ngarkohet menuja…",loadError:"Menuja nuk u ngarkua. Po shfaqen produktet shembull.",noProducts:"Nuk ka produkte në këtë kategori.",order:"Porosit"},
  en:{eyebrow:"FRESH • TASTY • HALAL",heroTitle:"A taste worth coming back for.",heroText:"Pizza, shawarma and fast-food favourites — carefully prepared and ready for you.",viewMenu:"Explore menu",madeFresh:"Made with care",ourMenu:"OUR MENU",chooseFavorite:"Pick your favourite.",menuSub:"See the ingredients and price of every item.",hungry:"FEELING HUNGRY?",readyToOrder:"Ready to place your order?",orderText:"Contact us to order or ask about our products.",callUs:"Call us",footerText:"Good food. Made with care.",ingredients:"INGREDIENTS",all:"All items",loading:"Loading menu…",loadError:"Menu could not load. Sample products are shown.",noProducts:"No items in this category.",order:"Order"},
  ar:{eyebrow:"طازج • لذيذ • حلال",heroTitle:"نكهة تستحق العودة من أجلها.",heroText:"بيتزا وشاورما وأشهى الوجبات السريعة، تُحضّر بعناية من أجلك.",viewMenu:"تصفح القائمة",madeFresh:"محضّر بعناية",ourMenu:"قائمتنا",chooseFavorite:"اختر ما تفضله.",menuSub:"اطّلع على مكونات وسعر كل منتج.",hungry:"هل أنت جائع؟",readyToOrder:"هل أنت مستعد للطلب؟",orderText:"تواصل معنا للطلب أو للاستفسار عن المنتجات.",callUs:"اتصل بنا",footerText:"طعام لذيذ، محضّر بعناية.",ingredients:"المكونات",all:"كل المنتجات",loading:"جارٍ تحميل القائمة…",loadError:"تعذر تحميل القائمة. يتم عرض منتجات تجريبية.",noProducts:"لا توجد منتجات في هذه الفئة.",order:"اطلب"},
  tr:{eyebrow:"TAZE • LEZZETLİ • HELAL",heroTitle:"Tekrar gelmeye değer bir lezzet.",heroText:"Pizza, shawarma ve sevilen fast food lezzetleri — özenle hazırlanır.",viewMenu:"Menüyü incele",madeFresh:"Özenle hazırlandı",ourMenu:"MENÜMÜZ",chooseFavorite:"Favorini seç.",menuSub:"Her ürünün içeriğini ve fiyatını incele.",hungry:"ACIKTIN MI?",readyToOrder:"Sipariş vermeye hazır mısın?",orderText:"Sipariş vermek veya ürünler hakkında bilgi almak için bize ulaş.",callUs:"Bizi ara",footerText:"Güzel lezzetler. Özenle hazırlanır.",ingredients:"İÇİNDEKİLER",all:"Tüm ürünler",loading:"Menü yükleniyor…",loadError:"Menü yüklenemedi. Örnek ürünler gösteriliyor.",noProducts:"Bu kategoride ürün yok.",order:"Sipariş ver"}
};
const categoryNames = {
  sq:{all:"Të gjitha",pizza:"Pica",shawarma:"Shawarma",burgers:"Burger",sides:"Shoqëruese",drinks:"Pije"},
  en:{all:"All",pizza:"Pizza",shawarma:"Shawarma",burgers:"Burgers",sides:"Sides",drinks:"Drinks"},
  ar:{all:"الكل",pizza:"بيتزا",shawarma:"شاورما",burgers:"برغر",sides:"أطباق جانبية",drinks:"مشروبات"},
  tr:{all:"Tümü",pizza:"Pizza",shawarma:"Shawarma",burgers:"Burger",sides:"Yan ürünler",drinks:"İçecekler"}
};
const sampleProducts = [
 {id:"demo-pizza",category:"pizza",price:500,currency:"ALL",image:"https://images.unsplash.com/photo-1579751626657-72bc17010498?auto=format&fit=crop&w=900&q=80",name:{sq:"Pica speciale",en:"Special Pizza",ar:"بيتزا خاصة",tr:"Özel Pizza"},description:{sq:"Pica e preferuar me shije të pasur.",en:"A favourite pizza with a rich flavour.",ar:"بيتزا مفضلة بنكهة غنية.",tr:"Zengin lezzetli favori pizza."},ingredients:{sq:"Brumë, salcë domatesh, mozzarella, sallam halal, rigon.",en:"Dough, tomato sauce, mozzarella, halal salami, oregano.",ar:"عجين، صلصة طماطم، موزاريلا، سلامي حلال، أوريغانو.",tr:"Hamur, domates sosu, mozzarella, helal salam, kekik."}},
 {id:"demo-shawarma",category:"shawarma",price:300,currency:"ALL",image:"https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&w=900&q=80",name:{sq:"Shawarma pule",en:"Chicken Shawarma",ar:"شاورما دجاج",tr:"Tavuk Shawarma"},description:{sq:"Shawarma e mbushur dhe e përgatitur në moment.",en:"A generously filled shawarma, prepared fresh.",ar:"شاورما محشوة بسخاء ومحضرة طازجة.",tr:"Bol malzemeli, taze hazırlanan shawarma."},ingredients:{sq:"Pulë, bukë, sallatë, domate, salcë hudhre.",en:"Chicken, flatbread, lettuce, tomato, garlic sauce.",ar:"دجاج، خبز، خس، طماطم، صلصة الثوم.",tr:"Tavuk, lavaş, marul, domates, sarımsak sosu."}},
 {id:"demo-burger",category:"burgers",price:350,currency:"ALL",image:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80",name:{sq:"Burger pule",en:"Chicken Burger",ar:"برغر دجاج",tr:"Tavuk Burger"},description:{sq:"Burger i shijshëm me perime të freskëta.",en:"A tasty burger with fresh vegetables.",ar:"برغر لذيذ مع خضروات طازجة.",tr:"Taze sebzeli lezzetli burger."},ingredients:{sq:"Bukë burgeri, pulë, sallatë, domate, salcë.",en:"Burger bun, chicken, lettuce, tomato, sauce.",ar:"خبز برغر، دجاج، خس، طماطم، صلصة.",tr:"Burger ekmeği, tavuk, marul, domates, sos."}},
 {id:"demo-fries",category:"sides",price:150,currency:"ALL",image:"https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=900&q=80",name:{sq:"Patate të skuqura",en:"French Fries",ar:"بطاطس مقلية",tr:"Patates Kızartması"},description:{sq:"Patate të arta dhe krokante.",en:"Golden and crispy fries.",ar:"بطاطس ذهبية ومقرمشة.",tr:"Altın renginde çıtır patatesler."},ingredients:{sq:"Patate, vaj, kripë.",en:"Potatoes, oil, salt.",ar:"بطاطس، زيت، ملح.",tr:"Patates, yağ, tuz."}}
];
let lang="sq", selectedCategory="all", products=[...sampleProducts], supabaseClient=null;
const $=s=>document.querySelector(s);
function tr(key){return (translations[lang]||translations.sq)[key]||translations.sq[key]||key}
function localized(obj){return obj && (obj[lang]||obj.sq||obj.en)||""}
function formatPrice(product){const currency=product.currency||"ALL";try{return new Intl.NumberFormat(lang==="sq"?"sq-AL":lang==="ar"?"ar":"en-GB",{style:"currency",currency,maximumFractionDigits:0}).format(Number(product.price)||0)}catch{return `${product.price} ${currency}`}}
function setLanguage(next){lang=next;document.documentElement.lang=lang;document.documentElement.dir=lang==="ar"?"rtl":"ltr";document.body.classList.toggle("rtl",lang==="ar");document.querySelectorAll("[data-i18n]").forEach(el=>{const k=el.dataset.i18n;if(translations[lang][k])el.textContent=translations[lang][k]});$("#header-order").textContent=tr("order");renderCategories();renderProducts()}
function renderCategories(){
 const holder=$("#category-list");holder.innerHTML="";
 const cats=["all","pizza","shawarma","burgers","sides","drinks"];
 cats.forEach(cat=>{if(cat!=="all"&&!products.some(p=>p.category===cat))return;const b=document.createElement("button");b.className="category-button"+(selectedCategory===cat?" active":"");b.textContent=categoryNames[lang][cat];b.type="button";b.onclick=()=>{selectedCategory=cat;renderCategories();renderProducts()};holder.appendChild(b)});
}
function renderProducts(){
 const grid=$("#product-grid");grid.innerHTML="";
 const filtered=products.filter(p=>(selectedCategory==="all"||p.category===selectedCategory)&&p.active!==false);
 if(!filtered.length){const empty=document.createElement("div");empty.className="empty-state";empty.textContent=tr("noProducts");grid.appendChild(empty);return}
 filtered.forEach(p=>{
  const card=document.createElement("article");card.className="product-card";
  const img=document.createElement("img");img.className="product-image";img.loading="lazy";img.alt=localized(p.name);img.src=p.image||"";
  img.onerror=()=>{img.style.display="none"};
  const info=document.createElement("div");info.className="product-info";
  const top=document.createElement("div");top.className="product-topline";
  const name=document.createElement("h3");name.className="product-name";name.textContent=localized(p.name);
  const price=document.createElement("span");price.className="product-price";price.textContent=formatPrice(p);
  top.append(name,price);
  const desc=document.createElement("p");desc.className="product-description";desc.textContent=localized(p.description);
  const label=document.createElement("p");label.className="ingredients-label";label.textContent=tr("ingredients");
  const ing=document.createElement("p");ing.className="ingredients";ing.textContent=localized(p.ingredients);
  info.append(top,desc,label,ing);card.append(img,info);grid.appendChild(card);
 });
}
async function loadProducts(){
 const cfg=window.SFH_CONFIG||{};
 if(cfg.SUPABASE_URL&&cfg.SUPABASE_ANON_KEY&&window.supabase){
  try{
   supabaseClient=window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY);
   const {data,error}=await supabaseClient.from("products").select("*").eq("active",true).order("sort_order",{ascending:true});
   if(error)throw error;
   if(data&&data.length){products=data;$("#menu-status").textContent="";renderCategories();renderProducts();return}
   if(data&&data.length===0){products=[];$("#menu-status").textContent="";renderCategories();renderProducts();return}
  }catch(e){console.warn("Supabase menu load:",e);$("#menu-status").textContent=tr("loadError")}
 }else{$("#menu-status").textContent=""}
 products=[...sampleProducts];renderCategories();renderProducts();
}
function configureContact(){
 const c=window.SFH_CONFIG||{},wa=(c.WHATSAPP_NUMBER||"").replace(/[^\d]/g,""),phone=(c.PHONE_NUMBER||"").trim();
 const waLink=$("#whatsapp-link"),phoneLink=$("#phone-link");
 if(wa){waLink.href=`https://wa.me/${wa}?text=${encodeURIComponent(lang==="sq"?"Përshëndetje! Dua të bëj një porosi.":"Hello! I'd like to place an order.")}`}
 else{waLink.href="https://wa.me/";waLink.addEventListener("click",e=>{if(!wa){e.preventDefault();alert(lang==="sq"?"Shto numrin e WhatsApp te config.js për të aktivizuar porositë.":"Add your WhatsApp number in config.js to enable ordering.")}})}
 if(phone){phoneLink.href=`tel:${phone}`}else{phoneLink.href="#";phoneLink.addEventListener("click",e=>{e.preventDefault();alert(lang==="sq"?"Shto numrin e telefonit te config.js për të aktivizuar telefonatat.":"Add your phone number in config.js to enable calls.")})}
}
$("#language").addEventListener("change",e=>{setLanguage(e.target.value);configureContact()});
$("#year").textContent=new Date().getFullYear();
setLanguage("sq");configureContact();loadProducts();
