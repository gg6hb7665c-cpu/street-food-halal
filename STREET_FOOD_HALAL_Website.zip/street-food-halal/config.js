/*
  KONFIGURIMI I FAQES
  1. Për fillim, mund t'i lësh fushat bosh: faqja shfaq menunë shembull.
  2. Për panelin që ruan ndryshimet për të gjithë, krijo projekt falas në Supabase
     dhe plotëso URL dhe anon key më poshtë.
  3. Anon/publishable key mund të jetë në kodin e faqes vetëm pasi të aktivizosh
     politikat RLS të SQL në README. MOS vendos kurrë service_role key këtu.
*/
window.SFH_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: "",
  WHATSAPP_NUMBER: "", // p.sh. 355681234567, pa +, hapësira apo viza
  PHONE_NUMBER: ""     // p.sh. +355681234567
};
