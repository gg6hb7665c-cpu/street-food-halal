let client=null, cachedProducts=[];
const $=s=>document.querySelector(s);
function message(el,text,error=false){el.textContent=text;el.classList.toggle("error",error)}
function cfgReady(){const c=window.SFH_CONFIG||{};return !!(c.SUPABASE_URL&&c.SUPABASE_ANON_KEY&&window.supabase)}
function productName(p){return p.name?.sq||p.name?.en||"Produkt pa emër"}
function resetForm(){ $("#product-form").reset();$("#product-id").value="";$("#product-active").checked=true;$("#product-order").value="0";$("#form-title").textContent="Shto produkt"; }
function setForm(p){
 $("#product-id").value=p.id||"";$("#product-category").value=p.category||"pizza";$("#product-price").value=p.price??0;$("#product-currency").value=p.currency||"ALL";$("#product-order").value=p.sort_order??0;$("#product-image").value=p.image||"";$("#product-active").checked=p.active!==false;
 for(const l of ["sq","en","ar","tr"]){$("#name-"+l).value=p.name?.[l]||"";$("#desc-"+l).value=p.description?.[l]||"";$("#ing-"+l).value=p.ingredients?.[l]||""}
 $("#form-title").textContent=p.id?"Ndrysho produktin":"Shto produkt";window.scrollTo({top:$("#product-form").getBoundingClientRect().top+window.scrollY-25,behavior:"smooth"});
}
function formProduct(){
 const get=id=>$("#"+id).value.trim();
 return {category:get("product-category"),price:Number(get("product-price")),currency:get("product-currency"),sort_order:Number(get("product-order")||0),image:get("product-image"),active:$("#product-active").checked,
  name:{sq:get("name-sq"),en:get("name-en"),ar:get("name-ar"),tr:get("name-tr")},
  description:{sq:get("desc-sq"),en:get("desc-en"),ar:get("desc-ar"),tr:get("desc-tr")},
  ingredients:{sq:get("ing-sq"),en:get("ing-en"),ar:get("ing-ar"),tr:get("ing-tr")}};
}
async function loadAdminProducts(){
 const box=$("#admin-product-list");box.innerHTML="Duke ngarkuar…";
 const {data,error}=await client.from("products").select("*").order("sort_order",{ascending:true});
 if(error){box.textContent="Gabim gjatë ngarkimit: "+error.message;return}
 cachedProducts=data||[];box.innerHTML="";
 if(!cachedProducts.length){box.textContent="Nuk ka produkte ende. Shto produktin e parë më poshtë.";return}
 cachedProducts.forEach(p=>{
  const row=document.createElement("div");row.className="admin-product-row";
  const img=document.createElement("img");img.src=p.image||"";img.alt="";img.onerror=()=>img.style.visibility="hidden";
  const info=document.createElement("div");info.className="row-info";
  const title=document.createElement("strong");title.textContent=productName(p);
  const meta=document.createElement("small");meta.textContent=`${p.price} ${p.currency||"ALL"} · ${p.category} · ${p.active===false?"Jo aktiv":"Aktiv"}`;
  info.append(title,meta);
  const actions=document.createElement("div");actions.className="row-actions";
  const edit=document.createElement("button");edit.type="button";edit.className="mini-button";edit.textContent="Ndrysho";edit.onclick=()=>setForm(p);
  const del=document.createElement("button");del.type="button";del.className="mini-button danger";del.textContent="Fshi";del.onclick=async()=>{if(!confirm(`Të fshihet "${productName(p)}"?`))return;const {error}=await client.from("products").delete().eq("id",p.id);if(error)message($("#admin-message"),"Gabim: "+error.message,true);else{message($("#admin-message"),"Produkti u fshi.");await loadAdminProducts()}};
  actions.append(edit,del);row.append(img,info,actions);box.append(row);
 });
}
async function init(){
 if(!cfgReady()){$("#setup-warning").hidden=false;$("#login-panel").hidden=true;return}
 $("#setup-warning").hidden=true;
 client=window.supabase.createClient(window.SFH_CONFIG.SUPABASE_URL,window.SFH_CONFIG.SUPABASE_ANON_KEY);
 const {data:{session}}=await client.auth.getSession();
 if(session)showEditor();else{$("#login-panel").hidden=false;$("#editor-panel").hidden=true}
 client.auth.onAuthStateChange((_event,session)=>{if(session)showEditor();else{$("#login-panel").hidden=false;$("#editor-panel").hidden=true}});
}
async function showEditor(){$("#login-panel").hidden=true;$("#editor-panel").hidden=false;await loadAdminProducts()}
$("#login-form").addEventListener("submit",async e=>{e.preventDefault();message($("#login-message"),"Duke hyrë…");const {error}=await client.auth.signInWithPassword({email:$("#login-email").value.trim(),password:$("#login-password").value});if(error)message($("#login-message"),"Nuk u krye hyrja: "+error.message,true);else message($("#login-message"),"Hyrja u krye.")});
$("#logout").addEventListener("click",async()=>{await client.auth.signOut();$("#login-panel").hidden=false;$("#editor-panel").hidden=true});
$("#new-product").addEventListener("click",()=>{resetForm();$("#product-form").scrollIntoView({behavior:"smooth"})});
$("#cancel-edit").addEventListener("click",resetForm);
$("#refresh-products").addEventListener("click",loadAdminProducts);
$("#product-form").addEventListener("submit",async e=>{
 e.preventDefault();if(!client)return;const p=formProduct();const id=$("#product-id").value;
 message($("#admin-message"),"Duke ruajtur…");
 let result;
 if(id)result=await client.from("products").update(p).eq("id",id);
 else result=await client.from("products").insert(p);
 if(result.error){message($("#admin-message"),"Nuk u ruajt: "+result.error.message,true);return}
 message($("#admin-message"),"Produkti u ruajt me sukses.");resetForm();await loadAdminProducts();
});
init();
