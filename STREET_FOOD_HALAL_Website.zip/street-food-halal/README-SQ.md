# STREET FOOD HALAL — Udhëzues në shqip

Ky projekt përfshin:
- `index.html` — faqja publike me menunë.
- `styles.css` — dizajni i faqes.
- `app.js` — gjuhët, filtrimi i kategorive dhe shfaqja e produkteve.
- `config.js` — numri i telefonit/WhatsApp dhe lidhja me Supabase.
- `admin.html`, `admin.css`, `admin.js` — paneli i administrimit.
- `supabase-setup.sql` — tabela dhe politikat e databazës.

## Çfarë është falas?

GitHub Pages mund ta publikojë falas këtë faqe statike në një repository publik. Supabase ka një plan falas, por kufijtë dhe kushtet e tij mund të ndryshojnë. Nuk nevojitet kartë për vetë skedarët e faqes në GitHub. Funksionet e databazës kërkojnë projekt Supabase dhe konfigurim.

## 1. Publiko skedarët në GitHub

1. Hyr te https://github.com/ dhe krijo llogari nëse nuk ke.
2. Shtyp `+` → `New repository`.
3. Emërtoje `street-food-halal`, zgjidh `Public` dhe krijoje.
4. Në repository zgjidh `Add file` → `Upload files`.
5. Ngarko të gjithë skedarët e këtij projekti (mund t'i nxjerrësh nga ZIP-i para ngarkimit).
6. Shtyp `Commit changes`.

## 2. Aktivizo GitHub Pages

1. Hape repository → `Settings` → `Pages`.
2. Te `Build and deployment`, zgjidh `Deploy from a branch`.
3. Zgjidh branch `main` dhe folder `/ (root)`.
4. Shtyp `Save`.
5. Pas disa minutash adresa zakonisht do të jetë:
   `https://EMRI-I-GITHUB.github.io/street-food-halal/`

## 3. Shto numrin e telefonit dhe WhatsApp

Hape `config.js` te GitHub dhe shtyp Edit (lapsi). Plotëso numrat, ruaj ndryshimet me `Commit changes`:

```js
window.SFH_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: "",
  WHATSAPP_NUMBER: "3556XXXXXXXX",
  PHONE_NUMBER: "+3556XXXXXXXX"
};
```

Zëvendëso numrat shembull me numrin real. Për WhatsApp përdor kodin e shtetit dhe numrin pa `+`, hapësira apo viza (p.sh. 355...). Për telefon mund të përdorësh `+355...`.

## 4. Aktivizo panelin e administrimit me Supabase

**Mos e anashkalo hapin e sigurisë SQL.** Pa databazë, faqja publike përdor produkte shembull. Ndryshimet e bëra vetëm në browser ose në local storage nuk do të shfaqen për klientët e tjerë. Supabase e zgjidh këtë.

1. Hyr te https://supabase.com/ dhe krijo projekt të ri. Zgjidh planin Free, nëse ofrohet për llogarinë/rajonin tënd.
2. Në projekt hap `SQL Editor` → `New query`.
3. Hape skedarin `supabase-setup.sql` nga ky projekt, kopjo të gjithë SQL-in dhe ekzekutoje me `Run`.
4. Shko te `Authentication` → `Users` → `Add user` (ose `Create new user`) dhe krijo një përdorues me emailin tënd dhe një fjalëkalim të fortë. Mos aktivizo regjistrimin publik për vizitorët.
5. Shko te `Project Settings` → `API` (në disa ndërfaqe quhet `Data API` / `API Keys`). Kopjo Project URL dhe anon/publishable key. **Mos kopjo service_role/secret key.**
6. Hape `config.js` në GitHub → Edit. Plotëso:
   - `SUPABASE_URL` me Project URL.
   - `SUPABASE_ANON_KEY` me anon/publishable key.
   - `WHATSAPP_NUMBER` dhe `PHONE_NUMBER` me numrat e tu.
7. Ruaj me `Commit changes` dhe prit të përditësohet faqja.
8. Hape `https://EMRI-I-GITHUB.github.io/street-food-halal/admin.html`, hyr me emailin dhe fjalëkalimin e administratorit, pastaj shto produktet e tua.

### Kontroll sigurie

SQL-i i jep të drejtë shkrimi përdoruesve të identifikuar, ndërsa vizitorët anonimë mund të lexojnë vetëm produktet aktive. Prandaj:
- Mbaje regjistrimin publik të çaktivizuar.
- Mos publiko `service_role` / secret key.
- Aktivizo vetëm një llogari admin që kontrollon ti.
- Mos e përdor panelin me fjalëkalim të dobët.
- Para përdorimit real, kontrollo politikat RLS në Supabase.

## 5. Si të shtosh ose ndryshosh produktet

1. Hape `admin.html` te faqja jote e publikuar.
2. Hyr si administrator.
3. Shtyp `Produkt i ri`, plotëso kategorinë, çmimin, monedhën, linkun e fotos, emrin, përshkrimin dhe përbërësit në katër gjuhë.
4. Shtyp `Ruaj produktin`.
5. Për ndryshim, shtyp `Ndrysho` pranë produktit ekzistues.
6. Për ta hequr nga menuja pa e fshirë, ndrysho statusin “Produkti shfaqet në menu”. Fshirja është përfundimtare.

### Fotografitë

Në këtë version, fotografia vendoset me URL të drejtpërdrejtë të imazhit. Linku duhet të jetë publik dhe të përfundojë te një foto që mund të hapet në browser. Përdor fotografi të biznesit tënd ose imazhe që ke të drejtë t'i përdorësh. Ngarkimi direkt i fotove nga telefoni nuk është përfshirë në këtë version fillestar.

## Shënime të rëndësishme

- Çmimet e produkteve shembull janë vetëm demonstrim. Ndryshoji përpara se ta promovosh faqen.
- Përbërësit shembull nuk janë deklaratë për recetën reale. Shkruaj përbërësit e vërtetë dhe kontrollo alergjenët.
- Për momentin porosia hap WhatsApp-in; nuk ka shportë porosie, pagesë online apo sistem dërgesash.
- Përmbajtja në katër gjuhë plotësohet manualisht në panel, që përkthimet të mos ndryshojnë gabimisht nga përkthimi automatik.
- Menuja në browser mund të shfaqë produkte shembull nëse Supabase nuk është konfiguruar. Mos e ngatërro këtë me menunë përfundimtare.
