-- STREET FOOD HALAL: ekzekutoje në Supabase > SQL Editor.
-- Tabela ruan tekstet e secilit produkt në katër gjuhë.
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  category text not null check (category in ('pizza','shawarma','burgers','sides','drinks')),
  price numeric(10,2) not null default 0 check (price >= 0),
  currency text not null default 'ALL' check (currency in ('ALL','EUR','TRY','USD')),
  image text not null default '',
  name jsonb not null default '{"sq":"","en":"","ar":"","tr":""}'::jsonb,
  description jsonb not null default '{"sq":"","en":"","ar":"","tr":""}'::jsonb,
  ingredients jsonb not null default '{"sq":"","en":"","ar":"","tr":""}'::jsonb,
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);
alter table public.products enable row level security;

-- Publiku mund të lexojë vetëm produktet aktive.
drop policy if exists "Public can read active products" on public.products;
create policy "Public can read active products"
on public.products for select to anon, authenticated
using (active = true);

-- Administratorët e identifikuar mund të shohin të gjitha produktet.
drop policy if exists "Authenticated can read all products" on public.products;
create policy "Authenticated can read all products"
on public.products for select to authenticated
using (true);

-- Vetëm përdoruesit e identifikuar mund të shtojnë/ndryshojnë/fshijnë.
drop policy if exists "Authenticated can insert products" on public.products;
create policy "Authenticated can insert products"
on public.products for insert to authenticated
with check (true);

drop policy if exists "Authenticated can update products" on public.products;
create policy "Authenticated can update products"
on public.products for update to authenticated
using (true) with check (true);

drop policy if exists "Authenticated can delete products" on public.products;
create policy "Authenticated can delete products"
on public.products for delete to authenticated
using (true);

-- SHËNIM I SIGURISË:
-- Mos aktivizo regjistrimin publik (public sign-ups). Krijo vetë një përdorues
-- administrator nga Supabase Authentication > Users > Add user.
-- Kjo tabelë lejon shkrim vetëm për authenticated, jo për anon.
